# CrossView

> **내 생각, 내가 지킨다**  
> 유튜브 뉴스·시사 영상 시청 중 편향도, AI 생성 의심 여부, 다른 관점 영상을 보여주고  
> 사용자의 시청 기록을 기반으로 개인 미디어 소비 리포트를 제공하는 AI 미디어 리터러시 서비스

---

## 지금 구현된 MVP

이 저장소는 CrossView의 1차 MVP 뼈대입니다.

### Chrome Extension

유튜브 영상 페이지에 접속하면 오른쪽 추천 영상 영역 상단에 CrossView 패널이 자동으로 삽입됩니다.

현재 구현된 기능:

- 유튜브 영상 페이지 자동 감지
- 오른쪽 추천 영역에 CrossView 패널 삽입
- 현재 영상 제목, 채널명, URL, videoId 수집
- 정치 편향도 막대그래프 UI
- AI 생성 의심 경고 UI
- 비슷한 관점 / 다른 관점 / 검증용 영상 추천 UI
- 현재는 mock 분석 결과 사용
- 추후 FastAPI 백엔드와 연결 가능

### Backend

FastAPI 기반 백엔드 뼈대입니다.

현재 구현된 기능:

- `/api/health`
- `/api/analyze`
- mock 분석 결과 반환
- 나중에 Gemini, Groq, OpenAI 등 AI Provider 교체 가능하도록 구조 분리

### Web

개인 리포트 사이트의 정적 프로토타입입니다.

현재 구현된 기능:

- 주간 시청 편향 리포트 mock 화면
- 좌/우/중립 시청 비율
- AI 의심 콘텐츠 비율
- 자주 본 주제
- CrossView 제안 문구

---

## 폴더 구조

```txt
crossview_mvp/
├── extension/
│   ├── manifest.json
│   ├── content.js
│   ├── background.js
│   └── crossview.css
├── backend/
│   ├── requirements.txt
│   └── app/
│       ├── main.py
│       ├── routes/
│       │   └── analyze.py
│       ├── schemas/
│       │   └── analysis.py
│       └── services/
│           └── ai_service.py
├── web/
│   ├── index.html
│   ├── style.css
│   └── report.js
├── .env.example
└── README.md
```

---

## Chrome Extension 실행 방법

1. Chrome 주소창에 `chrome://extensions` 입력
2. 오른쪽 위 **개발자 모드** 활성화
3. **압축해제된 확장 프로그램 로드** 클릭
4. `crossview_mvp/extension` 폴더 선택
5. 유튜브 영상 페이지 접속
6. 오른쪽 추천 영역 상단에 CrossView 패널 확인

---

## Backend 실행 방법

```bash
cd backend
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

백엔드 실행 후:

```txt
http://localhost:8000/api/health
```

---

## Web Report 실행 방법

`web/index.html` 파일을 브라우저에서 열면 됩니다.

---

## 다음 구현 순서

1. Extension에서 mock 분석 대신 `http://localhost:8000/api/analyze` 호출
2. YouTube Data API로 설명, 댓글, 검색 결과 연결
3. Gemini 무료 티어로 핵심 이슈, 편향도, AI 의심 여부 분석
4. PostgreSQL에 사용자별 분석 기록 저장
5. Web 대시보드에서 실제 사용자 리포트 표시

---

## 주의

AI 분석 결과는 확정 판정이 아니라 참고용입니다.  
UI에서도 “추정 편향도”, “AI 생성 가능성”, “다른 관점일 수 있는 영상”처럼 조심스럽게 표현합니다.
