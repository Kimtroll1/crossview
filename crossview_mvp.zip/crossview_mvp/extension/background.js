chrome.runtime.onInstalled.addListener(() => {
  console.log("CrossView installed");
});
