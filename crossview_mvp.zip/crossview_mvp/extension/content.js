const CROSSVIEW_BACKEND_URL = "http://localhost:8000/api/analyze";

let currentUrl = location.href;

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function getText(selector) {
  const element = document.querySelector(selector);
  return element ? element.innerText.trim() : "";
}

function getVideoId() {
  return new URLSearchParams(window.location.search).get("v") || "";
}

function getYouTubeContext() {
  const title =
    getText("h1 yt-formatted-string") ||
    getText("h1") ||
    document.title.replace(" - YouTube", "");

  const channelName =
    getText("ytd-channel-name a") ||
    getText("#owner #channel-name a") ||
    getText("#channel-name a") ||
    "채널 정보 없음";

  const description =
    getText("#description-inline-expander") ||
    getText("#description") ||
    "";

  return {
    videoId: getVideoId(),
    url: window.location.href,
    title,
    channelName,
    description,
    collectedAt: new Date().toISOString()
  };
}

function createMockRecommendation(title, kind, index) {
  const encoded = encodeURIComponent(title || "뉴스 이슈");
  const queries = {
    similar: `${encoded}+관련+분석`,
    opposite: `${encoded}+다른+관점`,
    verify: `${encoded}+팩트체크`
  };

  const labels = {
    similar: "비슷한 관점",
    opposite: "다른 관점일 수 있는 영상",
    verify: "검증용 영상"
  };

  return {
    title: `${labels[kind]} ${index}: 현재 이슈를 비교해볼 영상`,
    channel: "CrossView 추천",
    url: `https://www.youtube.com/results?search_query=${queries[kind]}`
  };
}

function getFallbackAnalysis(context) {
  const seed = Array.from(context.title || "CrossView").reduce(
    (sum, char) => sum + char.charCodeAt(0),
    0
  );

  const biasScore = (seed % 11) - 5;
  const aiRiskOptions = ["low", "medium", "high"];
  const aiRisk = aiRiskOptions[seed % aiRiskOptions.length];

  return {
    isPolitical: true,
    biasScore,
    biasLabel:
      biasScore < 0
        ? `좌측 성향 ${Math.abs(biasScore)}`
        : biasScore > 0
          ? `우측 성향 ${biasScore}`
          : "중립에 가까움",
    biasSummary:
      "현재는 mock 분석입니다. 실제 연결 후 제목, 설명, 자막, 댓글을 기반으로 편향도를 추정합니다.",
    aiRisk,
    aiSummary:
      aiRisk === "high"
        ? "AI 음성 또는 합성 콘텐츠일 가능성을 추가 확인해야 합니다."
        : aiRisk === "medium"
          ? "일부 자동 생성 콘텐츠 패턴이 의심됩니다."
          : "현재 기준 뚜렷한 AI 생성 징후는 낮습니다.",
    issue: "현재 영상의 핵심 이슈",
    similarVideos: [
      createMockRecommendation(context.title, "similar", 1),
      createMockRecommendation(context.title, "similar", 2)
    ],
    oppositeVideos: [
      createMockRecommendation(context.title, "opposite", 1),
      createMockRecommendation(context.title, "opposite", 2)
    ],
    verificationVideos: [
      createMockRecommendation(context.title, "verify", 1)
    ],
    checklist: [
      "이 주장의 근거가 영상 안에 직접 제시되었는가?",
      "다른 출처도 같은 내용을 말하는가?",
      "반대 관점에서는 이 이슈를 어떻게 설명하는가?",
      "감정적인 표현이 판단에 영향을 주고 있지 않은가?"
    ]
  };
}

async function requestAnalysis(context) {
  try {
    const response = await fetch(CROSSVIEW_BACKEND_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(context)
    });

    if (!response.ok) {
      throw new Error(`Backend error: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.warn("CrossView backend unavailable. Using mock analysis.", error);
    return getFallbackAnalysis(context);
  }
}

function biasToPercent(score) {
  const clamped = Math.max(-5, Math.min(5, Number(score) || 0));
  return ((clamped + 5) / 10) * 100;
}

function renderRecommendations(items) {
  return items
    .map((item) => `
      <a class="cv-rec-item" href="${item.url}" target="_blank" rel="noreferrer">
        <div class="cv-thumb"></div>
        <div>
          <p class="cv-rec-title">${escapeHtml(item.title)}</p>
          <p class="cv-rec-meta">${escapeHtml(item.channel || "추천 영상")}</p>
        </div>
      </a>
    `)
    .join("");
}

function renderChecklist(items) {
  return items
    .map((item) => `
      <label>
        <input type="checkbox" />
        <span>${escapeHtml(item)}</span>
      </label>
    `)
    .join("");
}

function aiRiskClass(risk) {
  if (risk === "high") return "high";
  if (risk === "medium") return "medium";
  return "low";
}

function aiRiskTitle(risk) {
  if (risk === "high") return "⚠ AI 생성 가능성 높음";
  if (risk === "medium") return "⚠ AI 생성 가능성 일부 의심";
  return "✅ AI 생성 징후 낮음";
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function buildPanel(context) {
  const panel = document.createElement("div");
  panel.id = "crossview-panel";

  panel.innerHTML = `
    <div class="cv-shell">
      <div class="cv-header">
        <div class="cv-title-row">
          <div class="cv-logo">CrossView</div>
          <div class="cv-badge">AI Media Report</div>
        </div>
        <p class="cv-subtitle">내 생각, 내가 지킨다 · 추천 영역을 균형 있게 다시 보기</p>
      </div>

      <div class="cv-body">
        <div class="cv-card">
          <p class="cv-section-title">현재 영상</p>
          <p class="cv-video-title">${escapeHtml(context.title || "제목 없음")}</p>
          <p class="cv-video-meta">${escapeHtml(context.channelName || "채널 정보 없음")}</p>
          <button class="cv-button" id="cv-analyze-btn">이 영상 분석하기</button>
          <p class="cv-status" id="cv-status">분석 버튼을 누르면 편향도, AI 의심 여부, 비교 영상을 보여줍니다.</p>
        </div>

        <div id="cv-result" class="cv-hidden">
          <div class="cv-card">
            <p class="cv-section-title">정치 편향도</p>
            <div class="cv-bias-scale">
              <div class="cv-scale-labels-top">
                <span>좌</span>
                <span>중립</span>
                <span>우</span>
              </div>
              <div class="cv-gradient-bar-wrap">
                <div class="cv-bias-marker" id="cv-bias-marker"></div>
              </div>
              <div class="cv-scale-numbers">
                <span>5</span><span>4</span><span>3</span><span>2</span><span>1</span>
                <span>0</span>
                <span>1</span><span>2</span><span>3</span><span>4</span><span>5</span>
              </div>
            </div>
            <p class="cv-analysis-text" id="cv-bias-text"></p>
          </div>

          <div class="cv-card">
            <p class="cv-section-title">AI 생성 의심 여부</p>
            <div class="cv-ai-warning low" id="cv-ai-box"></div>
          </div>

          <div class="cv-card">
            <p class="cv-section-title">비슷한 관점의 영상</p>
            <div class="cv-rec-list" id="cv-similar-list"></div>
          </div>

          <div class="cv-card">
            <p class="cv-section-title">다른 관점일 수 있는 영상</p>
            <div class="cv-rec-list" id="cv-opposite-list"></div>
          </div>

          <div class="cv-card">
            <p class="cv-section-title">검증용 영상 / 자료</p>
            <div class="cv-rec-list" id="cv-verify-list"></div>
          </div>

          <div class="cv-card">
            <p class="cv-section-title">판단 체크리스트</p>
            <div class="cv-checklist" id="cv-checklist"></div>
            <a class="cv-mini-link" href="http://localhost:3000" target="_blank">
              내 시청 편향 리포트 보기
            </a>
          </div>
        </div>
      </div>
    </div>
  `;

  return panel;
}

function updatePanelWithAnalysis(analysis) {
  const result = document.querySelector("#cv-result");
  const marker = document.querySelector("#cv-bias-marker");
  const biasText = document.querySelector("#cv-bias-text");
  const aiBox = document.querySelector("#cv-ai-box");
  const similarList = document.querySelector("#cv-similar-list");
  const oppositeList = document.querySelector("#cv-opposite-list");
  const verifyList = document.querySelector("#cv-verify-list");
  const checklist = document.querySelector("#cv-checklist");

  const biasPercent = biasToPercent(analysis.biasScore);
  marker.style.left = `${biasPercent}%`;

  biasText.textContent = `${analysis.biasLabel || "분석 결과 없음"} · ${analysis.biasSummary || ""}`;

  aiBox.className = `cv-ai-warning ${aiRiskClass(analysis.aiRisk)}`;
  aiBox.innerHTML = `<strong>${aiRiskTitle(analysis.aiRisk)}</strong><br>${escapeHtml(analysis.aiSummary || "")}`;

  similarList.innerHTML = renderRecommendations(analysis.similarVideos || []);
  oppositeList.innerHTML = renderRecommendations(analysis.oppositeVideos || []);
  verifyList.innerHTML = renderRecommendations(analysis.verificationVideos || []);
  checklist.innerHTML = renderChecklist(analysis.checklist || []);

  result.classList.remove("cv-hidden");
}

async function injectCrossViewPanel() {
  if (!location.href.includes("youtube.com/watch")) return;

  const secondary =
    document.querySelector("#secondary-inner") ||
    document.querySelector("#secondary");

  if (!secondary) return;

  const existing = document.querySelector("#crossview-panel");
  if (existing) existing.remove();

  const context = getYouTubeContext();
  const panel = buildPanel(context);

  secondary.prepend(panel);

  const analyzeButton = document.querySelector("#cv-analyze-btn");
  const status = document.querySelector("#cv-status");

  analyzeButton.addEventListener("click", async () => {
    analyzeButton.disabled = true;
    status.textContent = "CrossView가 현재 영상을 분석하는 중입니다...";

    const freshContext = getYouTubeContext();
    const analysis = await requestAnalysis(freshContext);

    updatePanelWithAnalysis(analysis);

    status.textContent = "분석이 완료되었습니다. 결과는 참고용이며 추가 확인이 필요합니다.";
    analyzeButton.disabled = false;
  });
}

async function boot() {
  for (let i = 0; i < 20; i += 1) {
    await injectCrossViewPanel();
    if (document.querySelector("#crossview-panel")) break;
    await wait(500);
  }
}

boot();

const observer = new MutationObserver(() => {
  if (location.href !== currentUrl) {
    currentUrl = location.href;
    setTimeout(boot, 800);
  }
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});
