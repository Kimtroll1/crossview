from urllib.parse import quote_plus
from app.schemas.analysis import VideoContext, AnalysisResponse, RecommendedVideo


class AIService:
    def __init__(self, provider: str = "mock"):
        self.provider = provider

    async def analyze_video(self, video: VideoContext) -> AnalysisResponse:
        if self.provider == "mock":
            return self._mock_analyze(video)

        # 나중에 여기서 Gemini, Groq, OpenAI 등으로 교체
        # 예:
        # if self.provider == "gemini":
        #     return await self._analyze_with_gemini(video)
        return self._mock_analyze(video)

    def _mock_analyze(self, video: VideoContext) -> AnalysisResponse:
        seed = sum(ord(ch) for ch in video.title or "CrossView")
        bias_score = (seed % 11) - 5

        if bias_score < 0:
            bias_label = f"좌측 성향 {abs(bias_score)}"
        elif bias_score > 0:
            bias_label = f"우측 성향 {bias_score}"
        else:
            bias_label = "중립에 가까움"

        ai_risk = ["low", "medium", "high"][seed % 3]
        ai_summary_map = {
            "low": "현재 기준 뚜렷한 AI 생성 징후는 낮습니다.",
            "medium": "일부 자동 생성 콘텐츠 패턴이 의심됩니다. 추가 확인이 필요합니다.",
            "high": "AI 음성 또는 합성 영상일 가능성을 주의해서 확인해야 합니다.",
        }

        base_query = quote_plus(video.title or "뉴스 이슈")

        return AnalysisResponse(
            isPolitical=True,
            biasScore=bias_score,
            biasLabel=bias_label,
            biasSummary=(
                "현재는 mock 분석입니다. 실제 연결 후 제목, 설명, 자막, 댓글을 기반으로 "
                "정치적 편향도와 근거를 추정합니다."
            ),
            aiRisk=ai_risk,
            aiSummary=ai_summary_map[ai_risk],
            issue="현재 영상의 핵심 이슈",
            similarVideos=[
                RecommendedVideo(
                    title="비슷한 관점으로 이슈를 다룬 영상 1",
                    channel="CrossView 추천",
                    url=f"https://www.youtube.com/results?search_query={base_query}+관련+분석",
                ),
                RecommendedVideo(
                    title="비슷한 관점으로 이슈를 다룬 영상 2",
                    channel="CrossView 추천",
                    url=f"https://www.youtube.com/results?search_query={base_query}+같은+관점",
                ),
            ],
            oppositeVideos=[
                RecommendedVideo(
                    title="다른 관점에서 비교해볼 영상 1",
                    channel="CrossView 추천",
                    url=f"https://www.youtube.com/results?search_query={base_query}+다른+관점",
                ),
                RecommendedVideo(
                    title="반대 주장을 확인해볼 수 있는 영상 2",
                    channel="CrossView 추천",
                    url=f"https://www.youtube.com/results?search_query={base_query}+반대+의견",
                ),
            ],
            verificationVideos=[
                RecommendedVideo(
                    title="팩트체크 또는 검증용 자료 검색",
                    channel="CrossView 추천",
                    url=f"https://www.youtube.com/results?search_query={base_query}+팩트체크",
                )
            ],
            checklist=[
                "이 주장의 근거가 영상 안에 직접 제시되었는가?",
                "다른 출처도 같은 내용을 말하는가?",
                "반대 관점에서는 이 이슈를 어떻게 설명하는가?",
                "감정적인 표현이 판단에 영향을 주고 있지 않은가?",
            ],
        )
