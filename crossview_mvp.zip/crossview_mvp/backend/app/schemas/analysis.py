from pydantic import BaseModel, Field
from typing import List, Optional


class VideoContext(BaseModel):
    videoId: str = ""
    url: str = ""
    title: str = ""
    channelName: str = ""
    description: str = ""
    collectedAt: Optional[str] = None


class RecommendedVideo(BaseModel):
    title: str
    channel: str = "CrossView 추천"
    url: str


class AnalysisResponse(BaseModel):
    isPolitical: bool = True
    biasScore: int = Field(default=0, ge=-5, le=5)
    biasLabel: str = "중립에 가까움"
    biasSummary: str
    aiRisk: str = "low"
    aiSummary: str
    issue: str = "핵심 이슈"
    similarVideos: List[RecommendedVideo]
    oppositeVideos: List[RecommendedVideo]
    verificationVideos: List[RecommendedVideo]
    checklist: List[str]
