# CrossView 구현 계획

## 1차 목표

- Chrome Extension이 YouTube 영상 페이지에서 자동 실행된다.
- 오른쪽 추천 영역 상단에 CrossView 패널을 삽입한다.
- 사용자가 분석 버튼을 누르면 mock 분석 결과를 보여준다.
- 정치 편향도 바, AI 생성 의심 경고, 다른 관점 추천 UI를 완성한다.

## 2차 목표

- FastAPI `/api/analyze`와 연결한다.
- Gemini 무료 티어 또는 다른 무료 AI API로 실제 분석을 수행한다.
- YouTube Data API로 영상 설명, 댓글, 검색 결과를 연결한다.

## 3차 목표

- 사용자별 분석 기록을 DB에 저장한다.
- Web Report에서 실제 시청 편향 리포트를 표시한다.
- 부족한 관점의 영상을 추천한다.
